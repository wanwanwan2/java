package com.greedy.section01.aritimetic;

public class Application1 {
	/*
	 * <pre>
	 * Class : Application1
	 * Comment : 산술연산자
	 * History
	 * 2023/01/13
	 * 2023/01/13
	 * </pre>
	 * @version 11
	 * @author 박완규
	 * @see 참고할 class 없음
	 * 
	 * */
	public static void main(String[] args) {
		
		/* 산술연산자 */
		
		int num1 = 20;
		int num2 = 7;
		
		System.out.println("num1 + num2 = " + (num1 + num2));
		System.out.println("num1 - num2 = " + (num1 - num2));
		System.out.println("num1 * num2 = " + (num1 * num2));
		System.out.println("num1 / num2 = " + (num1 / num2));
		System.out.println("num1 % num2 = " + (num1 % num2));
	}

}
