package com.greedy.section02.encapsulation.problem2;

public class Monster {

//	String name;
	int hp;
	String kind;
	}


