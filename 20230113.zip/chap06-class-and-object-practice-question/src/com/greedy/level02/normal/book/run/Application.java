package com.greedy.level02.normal.book.run;

import com.greedy.level02.normal.book.model.dto.BookDTO;

public class Application {

	public static void main(String[] args) {
		
		BookDTO book1 = new BookDTO();
		System.out.print(book1.printlnInformation());

		BookDTO book2 = new BookDTO("자바의 정석", "도우출판", "남궁성", 0, 0);
		System.out.print(book2.printlnInformation());

		BookDTO book3 = new BookDTO("홍길동전", "활빈당", "허균", 50000, 0.5);
		System.out.print(book3.printlnInformation());
		
		BookDTO book = new BookDTO();
		
		book.setTitle("자바의 정석");
		book.setTitle("도우출판");
		book.setTitle("남궁성");
		book.setTitle("0");
		book.setTitle("0.0");

	}
}
