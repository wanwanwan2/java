package com.greedy.section01.conditional.level01.basic;

public class Application1 {

	public static void main(String[] args) {

		Start1 a = new Start1 ();
		a.testNestedIfStatement();


	}

}

