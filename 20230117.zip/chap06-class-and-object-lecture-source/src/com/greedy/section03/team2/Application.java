package com.greedy.section03.team2;

import java.util.Scanner;

public class Application {

public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		    int balance = 100000000;
		
		
	       Borrower borrower = new Borrower();
		
	       Scanner sc = new Scanner(System.in);
		    
		    while(true) {
				System.out.println("====== 싸다 사채  =======");
				System.out.println("====== 메뉴를 선택하세요 =======");
								
				
				System.out.println("1. 빌리기");
				System.out.println("2. 갚기");
				
				
				System.out.println("9. 프로그램 종료");
				System.out.print("메뉴 선택 : ");
				int no = sc.nextInt();

				switch(no) {
					case 1 :System.out.println("얼마를 빌려드릴까요");
						   int amount = sc.nextInt();							
						   borrower.borrow(amount); break;
					case 2 :System.out.println("뭘로 갚으시겠어요? 1:안구 2:신장");
					        int kind = sc.nextInt();
						    borrower.payback(kind); break;
					case 9 : System.out.println("프로그램을 종료합니다."); return;
					default : System.out.println("잘못된 번호를 선택하셨습니다."); break;
				}
			}
		    
		    
		    

	}
}
