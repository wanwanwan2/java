package com.greedy.section05.overloading;

public class OverloadingTest {

	public void test() {}
	
//	public void test() {}

//	private void test() {}
	
//	public int test() { return 0;}
	
	public void test(int num) {}
	
//	public void test(int num) {}
	
	public void test(int num1, int num2) {}
	
	public void test(int num, String name) {}
	
	public void test(String name, int num) {}
	
	
}
