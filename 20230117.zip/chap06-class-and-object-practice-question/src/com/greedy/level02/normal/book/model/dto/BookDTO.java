package com.greedy.level02.normal.book.model.dto;

public class BookDTO {
	
	private String title;
	private String publisher;
	private String author;
	private int price;
	private double discountRate; 
	
	public BookDTO() {
		System.out.println();
	}                  
	/* 매개변수 있는 생성자 */
	public BookDTO(String title, String publisher, String author) {
		
		this.title = title;
		this.publisher = publisher;
		this.author = author;
		
		System.out.println();
	}
	
	public BookDTO(String title, String publisher, String author, int price, double discountRate) {
		
		this(title, publisher, author);
		this.price = price;
		this.discountRate = discountRate;
		System.out.println();
	}

	public String printlnInformation() {
	return this.title+"," + " " + this.publisher +"," + " " + this.author +"," + " " + this.price+ "," + " " + this.discountRate;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	public void setAutor(String author) {
		this.author = author;
	}
	
	public void setPrice(int price) {
		this.price = price;
	}
	
	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getPublisher() {
		return publisher;
	}
	
	public int getPrice() {
		return price;
	}
	
	public double getDiscountRate() {
		return discountRate;
	}
	
}