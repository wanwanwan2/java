package com.greedy.section02.encapsulation.problem2;

public class Monster {
	
//	String name;
	String kinds;
	int hp;
}
