package com.greedy.section05.calendar;

public class Application4 {

	public static void main(String[] args) {
		
		/* 0년 1월 1일 부터 오늘까지 몇 일이나 지났을까요? 
		 * 단, 중간에 윤년을 고려해야함
		 * */
		
	}

}
