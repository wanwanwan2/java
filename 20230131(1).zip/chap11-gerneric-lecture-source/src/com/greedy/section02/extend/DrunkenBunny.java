package com.greedy.section02.extend;

public class DrunkenBunny extends Bunny {

	@Override
	public void cry() {
		System.out.println("봐니봐니 봐니봐니 당근! 당근~#ㄲ@#$@#");
	}
}
