package com.greedy.section02.extend;

public class Bunny extends Rabbit {
	
	@Override
	public void cry() {
		System.out.println("바니바니 바니바니 당근 당근");
	}

}
