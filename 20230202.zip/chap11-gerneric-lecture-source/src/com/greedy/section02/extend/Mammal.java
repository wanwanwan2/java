package com.greedy.section02.extend;

public class Mammal implements Animal {

}
