package com.greedy.section03.overriding;

public class SuperClass {
	
	public void method(int num) {}
	
	private void privateMethod() {}
	
	public final void finalMethod() {} 
	
	protected void protectedMethod () {}
	
}
