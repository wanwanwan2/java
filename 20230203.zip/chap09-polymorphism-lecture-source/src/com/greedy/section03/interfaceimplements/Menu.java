package com.greedy.section03.interfaceimplements;

public interface Menu {
	
	public static int RICE = 0;
	public static int BREAD = 1;
	public static int WATER = 2;
	
}
