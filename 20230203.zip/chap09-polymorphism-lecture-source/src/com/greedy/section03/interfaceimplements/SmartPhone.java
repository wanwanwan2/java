package com.greedy.section03.interfaceimplements;

public interface SmartPhone {

}
