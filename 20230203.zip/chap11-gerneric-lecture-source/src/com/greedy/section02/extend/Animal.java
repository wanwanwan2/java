package com.greedy.section02.extend;

public interface Animal {

}
