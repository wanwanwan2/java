package com.greedy.section02.userexception.exception;

public class NegativeException extends Exception {

	public NegativeException() {}
	
	public NegativeException(String message) {
		super(message);
	}
}
