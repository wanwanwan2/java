package com.greedy.section02.userexception.exception;

public class NotEnoughMoneyException extends NegativeException {
	
	public NotEnoughMoneyException() {}

	public NotEnoughMoneyException(String message) {
		super(message);
	}
	
}
