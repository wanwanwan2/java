package com.greedy.section01.mouseandkey;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JTextField;

public class B_KeyEvent extends JFrame implements KeyListener {

   public B_KeyEvent() {

      this.setTitle("Keybord Event");
      this.setLocationRelativeTo(null);
      this.setSize(300, 200);

      JTextField tf = new JTextField();
      
      tf.addKeyListener(this);

      this.add(tf);

      this.setVisible(true);
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }

   public static void main(String[] args) {
      new B_KeyEvent();
   }

   public void display(String s, KeyEvent e) {
      char c = e.getKeyChar();
      int keyCode = e.getKeyCode();

      String moifiers = e.isAltDown() + " " + e.isControlDown() + " " + e.isShiftDown();

      System.out.println(s + " " + c + " " + keyCode + " " + moifiers);
   }

   @Override
   public void keyTyped(KeyEvent e) {
      this.display("KeyTyped : ", e);
   }

   @Override
   public void keyPressed(KeyEvent e) {
      this.display("KeyPressed : ", e);
   }

   @Override
   public void keyReleased(KeyEvent e) {
      this.display("KeyReleased : ", e);
   }
}