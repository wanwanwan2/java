package com.greedy.section02.uses;

public class Application {

	public static void main(String[] args) {
		
		new B_OtherClassTest();
		
	}

}
