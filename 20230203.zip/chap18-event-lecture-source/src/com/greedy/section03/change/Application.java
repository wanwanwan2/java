package com.greedy.section03.change;

public class Application {

	public static void main(String[] args) {
	
		new MainFrame();
		

	}

}


