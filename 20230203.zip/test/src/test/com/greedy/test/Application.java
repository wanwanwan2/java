package test.com.greedy.test;

public class Application {

}
