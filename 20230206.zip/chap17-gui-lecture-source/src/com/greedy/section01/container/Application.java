package com.greedy.section01.container;

public class Application {

	public static void main(String[] args) {
		
//		new JFrameTest1();
		new JFrameTest2().showMainFrame();
	}
}
