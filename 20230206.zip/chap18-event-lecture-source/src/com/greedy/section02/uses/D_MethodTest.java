//package com.greedy.section02.uses;
//
//import javax.swing.JButton;
//import javax.swing.JFrame;
//import javax.swing.JLabel;
//import javax.swing.JPanel;
//
//public class D_MethodTest extends JFrame implemnts ActionEvents {
//	
//	public D_MethodTest() {
//		this.setSize(300, 200);
//		
//		JPanel panel = new JPanel();
//		JButton bytton = new JButton("버튼을 눌러보세요");
//		JLabel label = new JLabel("아직 버튼이 눌려지지 않았습니다.")
//		
//		panel.add(button);
//		panel.add(label);
//		
//		button.addActionListener(this);
//		
//		this.add(panel);
//		
//		
//		this.setVisible(true);
//		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//	}
//	
//	public static void main(String[] args) {
//	
//		new D_MethodTest();
//		
//	}
//
//}
