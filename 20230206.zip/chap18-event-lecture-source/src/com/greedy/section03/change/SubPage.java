package com.greedy.section03.change;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class SubPage extends JPanel {

	public SubPage() {
		this.setSize(300, 200);
		this.setBackground(Color.YELLOW);
	}
	
//	public static void main(String[] args) {
//		JFrame mf = new JFrame();
//		mf.setSize(300, 200);
//		
//		mf.add(300,200);
//		
//		mf.setVisible(true);
//		mf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//	}
}
