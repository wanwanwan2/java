package com.greedy.section01.crud.view;

public class CreateMenuResultView {
	
	public void success() {
		System.out.println("메뉴 등록에 성공하셨습니다.");
	}
	
	public void fail() {
		System.out.println("메뉴 등록에 실패하셨습니다.");
	}
}
