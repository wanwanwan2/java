package com.greedy.member.model.dto;

import java.sql.Date;

public class MemberDTO {

	private int number;
	private String id;
	private String pwd;
	private String name;
	private String gender;
	private String email;
	private String phone;
	private String address;
	private int age;
	private Date enrolldate;
	

	public MemberDTO(int number, String id, String pwd, String name, String gender, String email, String phone,
			String address, int age, Date enrolldate) {
		super();
		this.number = number;
		this.id = id;
		this.pwd = pwd;
		this.name = name;
		this.gender = gender;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.age = age;
		this.enrolldate = enrolldate;
	}


	public MemberDTO() {}


	public int getNumber() {
		return number;
	}


	public void setNumber(int number) {
		this.number = number;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getPwd() {
		return pwd;
	}


	public void setPwd(String pwd) {
		this.pwd = pwd;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public Date getEnrolldate() {
		return enrolldate;
	}


	public void setEnrolldate(Date enrolldate) {
		this.enrolldate = enrolldate;
	}


	@Override
	public String toString() {
		return "MemberDTO [number=" + number + ", id=" + id + ", pwd=" + pwd + ", name=" + name + ", gender=" + gender
				+ ", email=" + email + ", phone=" + phone + ", address=" + address + ", age=" + age + ", enrolldate="
				+ enrolldate + "]";
	}

	
}