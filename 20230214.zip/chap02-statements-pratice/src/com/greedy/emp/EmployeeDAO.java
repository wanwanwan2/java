package com.greedy.emp;

public class EmployeeDAO {
	/* 구현 조건
	 * 1. Connection 생성은 JDBC 템플릿 사용
	 * 2. query문은 xml 파일로 분리
	 * 3. 쿼리문에 값을 전달해야하는 경우는 PreparedStatemnet, 아닌 경우는 Statement 사용
	 * 4. 한 행 정보는 DTO에 담아 출력, 여러 행 정보는 ArrayList 에 담아 출력 */
	public void findOneEmpByEmpId(String empId) {
		
		/* 사번으로 직원정보 조회 후 EmployeeDTO에 담아 출력 */
	}

	public void findAllEmpByEmpId(String allId) {
		// TODO Auto-generated method stub
		
	}

	public void findGenderEmpByEmpId(String genId) {
		// TODO Auto-generated method stub
		
	}

	public void findSalaryAscEmpByEmpId(String salAscId) {
		// TODO Auto-generated method stub
		
	}

	public void findSalaryDescEmpByEmpId(String salDescId) {
		// TODO Auto-generated method stub
		
	}

	public void findDateAscEmpByEmpId(String dateAscId) {
		// TODO Auto-generated method stub
		
	}

	public void findDateDescEmpByEmpId(String dateDescId) {
		// TODO Auto-generated method stub
		
	}

	public void findRankFive(String rankFive) {
		// TODO Auto-generated method stub
		
	}

	public void findRankSix(String rankSix) {
		// TODO Auto-generated method stub
		
	}


}
