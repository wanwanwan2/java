package com.greedy.emp;

import java.util.Scanner;

public class MainMenu {

	public void displayMenu() {

		Scanner sc = new Scanner(System.in);
		EmployeeDAO empDAO = new EmployeeDAO();
		do {
			System.out.println("====== 직원 정보 조회 프로그램 =======");
			System.out.println("1. 사원 번호로 직원 정보 조회");
			System.out.println("2. 전체 직원 정보 조회");
			System.out.println("3. 성별로 직원 정보 조회");
			System.out.println("4. 급여순 오름차순 정렬 조회");
			System.out.println("5. 급여순 내림차순 정렬 조회");
			System.out.println("6. 입사일 순 오름차순 조회");
			System.out.println("7. 입사일 순 내림차순 조회");
			System.out.println("8. 급여 상위 5명 조회");
			System.out.println("9. 급여 상위 6위 ~ 10위 조회");
			System.out.println("0. 프로그램 종료");
			System.out.println("==============================");
			System.out.println("메뉴 번호 입력 : ");
			int no = sc.nextInt();

			switch (no) {
			case 1:
				empDAO.findOneEmpByEmpId(EmpId());
				break;
			case 2:
				empDAO.findAllEmpByEmpId(AllId());
				break;
			case 3:
				empDAO.findGenderEmpByEmpId(GenId());
				break;
			case 4:
				empDAO.findSalaryAscEmpByEmpId(SalAscId());
				break;
			case 5:
				empDAO.findSalaryDescEmpByEmpId(SalDescId());
				break;
			case 6:
				empDAO.findDateAscEmpByEmpId(DateAscId());
				break;
			case 7:
				empDAO.findDateDescEmpByEmpId(DateDescId());
				break;
			case 8:
				empDAO.findRankFive(RankFive());
				break;
			case 9:
				empDAO.findRankSix(RankSix());
				break;
			case 0:
				System.out.println("프로그램을 종료합니다.");
				return;

			}

		} while (true);

	}

	private String RankSix() {
		Scanner sc = new Scanner(System.in);
		System.out.println("급여 상위 6위 ~ 10위 조회");
		String rankSix = sc.nextLine();
		return rankSix;
	}

	private String RankFive() {
		Scanner sc = new Scanner(System.in);
		System.out.println("급여 상위 5명 조회");
		String rankFive = sc.nextLine();
		return rankFive;
	}

	private String DateDescId() {
		Scanner sc = new Scanner(System.in);
		System.out.println("조회할 입사일 내림차순 날짜");
		String dateDescId = sc.nextLine();
		return dateDescId;
	}

	private String DateAscId() {
		Scanner sc = new Scanner(System.in);
		System.out.println("조회할 입사일 오름차순 날짜");
		String dateAscId = sc.nextLine();
		return dateAscId;
	}

	private String SalDescId() {
		Scanner sc = new Scanner(System.in);
		System.out.println("조회할 내림차순 급여");
		String salDescId = sc.nextLine();
		return salDescId;
	}

	private String SalAscId() {
		Scanner sc = new Scanner(System.in);
		System.out.println("조회할 오름차순 급여");
		String salAscId = sc.nextLine();
		return salAscId;
	}

	private String GenId() {

		Scanner sc = new Scanner(System.in);
		System.out.println("조회할 성별을 입력하세요 : ");
		String genId = sc.nextLine();
		return genId;
	}

	private String AllId() {

		Scanner sc = new Scanner(System.in);
		System.out.println("조회할 전체 직원 번호를 입력하세요 : ");
		String allId = sc.nextLine();
		return allId;
	}

	private String EmpId() {

		Scanner sc = new Scanner(System.in);
		System.out.println("조회할 사번을 입력하세요 : ");
		String empId = sc.nextLine();

		return empId;

	}

}
