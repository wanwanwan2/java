package com.greedy.section01.crud.run;

import com.greedy.section01.crud.view.MainMenu;

public class Application1 {

	public static void main(String[] args) {
	
		new MainMenu().displayMenu();

	}

} 

