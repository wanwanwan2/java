package test;

public class LoginPage {

}
