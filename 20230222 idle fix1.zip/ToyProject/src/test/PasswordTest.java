package test;

import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PasswordTest extends JFrame {

	private JFrame myPage;

	public PasswordTest() {
		Font labelFont = new Font("DungGeunMo", Font.PLAIN, 25);
		Font textFont = new Font("DungGeunMo", Font.PLAIN, 20);

		this.myPage = this;
		myPage.setSize(800, 500);
		myPage.setLocationRelativeTo(null);
		myPage.setResizable(false);

		JPanel panel = new JPanel();

		panel.setLayout(null);

		Image backgrond = new ImageIcon("images/LoginBackground.png").getImage().getScaledInstance(800, 500, 0); // 배경

		JLabel background = new JLabel(new ImageIcon(backgrond));
		background.setSize(800, 500);
		background.setLocation(0, -30);
		
		JLabel label = new JLabel("아이디");
		label.setFont(labelFont);
		label.setSize(200, 30);
		label.setLocation(200, 200);
		panel.add(label);
		
		JLabel label2 = new JLabel("비밀번호");
		label2.setFont(labelFont);
		label2.setSize(200, 30);
		label2.setLocation(200, 300);
		panel.add(label2);
		
		panel.add(background);

		myPage.add(panel);

		myPage.setVisible(true);
		myPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}
}