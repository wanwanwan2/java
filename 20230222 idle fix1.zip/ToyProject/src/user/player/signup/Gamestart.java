package user.player.signup;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import test.LoginPage;

public class Gamestart extends JFrame {
	
    private JFrame myPage;
	
	public Gamestart() {
			
	      this.myPage = this;
	      myPage.setSize(800, 500);
	      myPage.setLocationRelativeTo(null);
	      myPage.setResizable(false);
		
	      JPanel panel = new JPanel();
	      
	      panel.setLayout(null);
			
	      ImageIcon backgrond = new ImageIcon("images/start.png"); // 배경
	      
	      Image backImg = new ImageIcon("images/connecting.png").getImage().getScaledInstance(50, 35, 0);
	      ImageIcon back = new ImageIcon(backImg); // 이전화면
	      
	      JLabel background = new JLabel(backgrond);
	      background.setSize(800, 500);
	      background.setLocation(0, 0);
	      
	      JLabel backLabel = new JLabel(back);
	      backLabel.setSize(back.getIconWidth(), back.getIconHeight());
	      backLabel.setLocation(30, 10);
	      
	      JButton backBtn = new JButton();
	      backBtn.setBorderPainted(false);
	      backBtn.setContentAreaFilled(false);
	      backBtn.setFocusPainted(false);
	      backBtn.setSize(70, 49);
	      backBtn.setLocation(30, 10);   
	      
	      panel.add(backLabel);
	      panel.add(background);
	      
	      myPage.add(panel);

	      myPage.setVisible(true);
	      myPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      
	}
}
