package user.player.signup.controller;

import java.util.Map;

import user.player.common.dto.IngreDTO;
import user.player.signup.service.IngreService;

public class IngreController {
	private IngreService ingreService = new IngreService();

	public boolean insertNewIngre(Map<String, String> map) {

		IngreDTO ingre = new IngreDTO();
		ingre.setNumber(map.get("no"));
		ingre.setName(map.get("name"));
		ingre.setPrice(map.get("price"));
		ingre.setImage(map.get("image"));

		boolean isCreate = ingreService.insertNewIngre(ingre);

		return isCreate;
	}
}