package user.player.realplay;

public class SearchCriteria {

}
