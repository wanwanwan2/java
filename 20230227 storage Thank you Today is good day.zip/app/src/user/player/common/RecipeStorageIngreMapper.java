package user.player.common;

import java.util.List;

import user.player.common.dto.RecipeStorageIngreDTO;

public interface RecipeStorageIngreMapper {

	public List<RecipeStorageIngreDTO> findRecipeStorageIngre();
	
}
