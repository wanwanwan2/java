package user.player.ingreup.controller;

import java.util.List;

import user.player.common.dto.RecipeStorageIngreDTO;
import user.player.ingreup.service.RecipeStorageIngreService;

public class RecipeStorageIngreController {
	private RecipeStorageIngreService recipeStorageIngreService = new RecipeStorageIngreService();
	
	public List<RecipeStorageIngreDTO> findRecipeStorageIngre() {
		
		List<RecipeStorageIngreDTO> recipeStorageIngreDTO = recipeStorageIngreService.findRecipeStorageIngre();
		
		return recipeStorageIngreDTO;
	}

}
