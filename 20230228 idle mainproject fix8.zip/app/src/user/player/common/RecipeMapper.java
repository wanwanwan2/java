package user.player.common;

import java.util.List;

import user.player.common.dto.RecipeDTO;

public interface RecipeMapper {

	public List<RecipeDTO> selectAllrecipe();
	
	
}
