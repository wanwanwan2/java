package user.player.common;

import user.player.common.dto.StoreDTO;

public interface UserLevelMapper {

	StoreDTO selectUserLevel();

}
