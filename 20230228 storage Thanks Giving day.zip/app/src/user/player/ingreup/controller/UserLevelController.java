package user.player.ingreup.controller;

import java.util.List;

import user.player.common.dto.RecipeDTO;
import user.player.common.dto.StoreDTO;
import user.player.ingreup.service.RecipeService;
import user.player.ingreup.service.UserLevelService;

public class UserLevelController {
	
	private UserLevelService UserLevelService = new UserLevelService();
	
	public StoreDTO findUserLevel() {

		StoreDTO storeDTO = UserLevelService.findUserLevel();

		return storeDTO;

	}
}
