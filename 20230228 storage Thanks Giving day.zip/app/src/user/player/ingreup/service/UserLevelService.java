package user.player.ingreup.service;

import static user.player.common.Template.getSqlSession;


import org.apache.ibatis.session.SqlSession;


import user.player.common.UserLevelMapper;
import user.player.common.dto.StoreDTO;

public class UserLevelService {

	private UserLevelMapper mapper;
	
	public StoreDTO findUserLevel() {
		
		SqlSession sqlSession = getSqlSession();
		mapper = sqlSession.getMapper(UserLevelMapper.class);
		
		StoreDTO storeDTO = mapper.selectUserLevel();

		sqlSession.close();

		return storeDTO;
	}

}
