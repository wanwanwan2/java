package com.greedy.section02.layout.run;

import com.greedy.section02.layout.A_BorderLayout;
import com.greedy.section02.layout.B_FlowLayout;
import com.greedy.section02.layout.C_GridLayout;
import com.greedy.section02.layout.D_CardLayout;
import com.greedy.section02.layout.E_NullLayout;
import com.greedy.section02.layout.F_PanelLayout;

public class Application {

	public static void main(String[] args) {
//		new A_BorderLayout();
//		new B_FlowLayout();
//		new C_GridLayout();
//		new D_CardLayout();
//		new E_NullLayout();
		new F_PanelLayout();
	}

}
