package user.player.signup;

public class LoginPage {

}
