package practice.parameter;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class ParameterTest {

	public void primitiveTypeParameter(int num) {
	
		System.out.println("매개변수로 전달받은 값 : " + num);
	}
	public void primitiveTypeArrayParameter(int[] iarr) {
		
		System.out.println("매개변수로 전달받은 값 : " + iarr);
		
		for(int i = 0; i < iarr.length; i++) {
			System.out.println(iarr[i] + " ");
		}
		System.out.println();
		
		iarr[0] = 99;
		
		for(int i = 0; i < iarr.length; i++) {
			System.out.println(iarr[i] + " ");
		}
		System.out.println();
	}
	
	public void classTypeParameter(RectAngle rectAngle) {
		
		System.out.println("매개변수로 전달받은 값 : " + rectAngle);
		
		System.out.println("사각형의 넓이와 둘레 =============");
		rectAngle.calcArea();
		rectAngle.calcRound();
		
		rectAngle.setWidth(100);
		rectAngle.setHeight(100);
		
		System.out.println("변경 후 사각형의 넓이와 둘레 =========");
		rectAngle.calcArea();
		rectAngle.calcRound();		
	}
	
	public void variableLengthArrayParameter(String name, String...hobby) {
		
		System.out.println("이름 : " + name);
		System.out.println("취미 : " + hobby);
		System.out.println("취미의 갯수 : " + hobby.length);
		
		for(int i = 0; i < hobby.length; i++) {
			System.out.print(hobby[i] + " ");
		}
		System.out.println();
	}
	
//	public void variableLengthArrayParameter(String...hobby) {}
}
