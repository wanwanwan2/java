package practice.constructor;

public class User {

	 

}
