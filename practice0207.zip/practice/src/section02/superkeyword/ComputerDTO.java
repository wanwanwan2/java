package section02.superkeyword;

import java.util.Date;

public class ComputerDTO extends ProductDTO {

	private String cpu;					//cpu
	private int hdd;					//hdd
	private int ram;					//ram
	private String operationSystem;		//운영체제
	
	public ComputerDTO() {
		System.out.println("ComputerDTO 클래스의 기본생성자 호출함...");
	}

	public ComputerDTO(String cpu, int hdd, int ram, String operationSystem) {
		super();
		this.cpu = cpu;
		this.hdd = hdd;
		this.ram = ram;
		this.operationSystem = operationSystem;
	
		System.out.println("ComputerDTO 클래스의 모든 필드를 초기화하는 생성자 호출함...");;
	
	}

	public ComputerDTO(String code, String brand, String name, int price, Date manufacturingDate, String cpu, int hdd,
			int ram, String operationSystem) {
		super(code, brand, name, price, manufacturingDate);
		this.cpu = cpu;
		this.hdd = hdd;
		this.ram = ram;
		this.operationSystem = operationSystem;
		
		System.out.println("ComputerDTO 클래스의 부모 필드도 초기화하는 생성자 호출함...");
	}

	public String getCpu() {
		return cpu;
	}

	public void setCpu(String cpu) {
		this.cpu = cpu;
	}

	public int getHdd() {
		return hdd;
	}

	public void setHdd(int hdd) {
		this.hdd = hdd;
	}

	public int getRam() {
		return ram;
	}

	public void setRam(int ram) {
		this.ram = ram;
	}

	public String getOperationSystem() {
		return operationSystem;
	}

	public void setOperationSystem(String operationSystem) {
		this.operationSystem = operationSystem;
	}
	
	@Override
	public String getInformation() {
		
		return super.getInformation()+
				"ComputerDTO [cpu=" + cpu + 
				", hdd=" + hdd + 
				", ram=" + ram + 
				", operationSystem=" + operationSystem
				+ "]";
	}

	
		
}
