package section04.bonus;

public class Calculator {

		public int sumTwoNumber(int i, int j) {
			
			return i + j;
		}
}
