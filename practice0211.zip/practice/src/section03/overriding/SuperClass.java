package section03.overriding;

public /* final */ class SuperClass {

		public void method(int num) {}
		
		private void privateMethod() {}
		
		public final void finalMethod() {}
		
		protected void protectedMethod() {}
}
