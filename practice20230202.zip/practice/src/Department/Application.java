package Department;

import java.util.Scanner;

public class Application {

	public static void main(String[] args) {
	
		/* DTO를 활용한 간단한 회원 관리용 프로그램
		 * 1. 여러개의 가전제품의 정보를 받아 한 번에 여러 가전제품을 등록
		 * 2. 전체 회원 조회시 여러명의 회원 정보를 반환
		 * */
	
		Scanner sc = new Scanner(System.in);
		ProductManager productManager = new ProductManager();
		
		while(true) {
			System.out.println("====== 주문 관리 프로그램 ======");
			System.out.println("1. 제품 주문");
			System.out.println("2. 주문 제품 전체 조회");
			System.out.println("9. 프로그램 종료");
			System.out.print("메뉴 선택");
			int no = sc.nextInt();
		
			switch(no) {
				case 1:
					productManager.signUpProducts();
					break;
				case 2:
					productManager.printAllProducts();
					break;
				case 9:
					System.out.println("프로그램을 종료합니다.");
					return;
				default :
					System.out.println("잘못된 번호를 입력하셨습니다.");
					break;
			}		
		}
	}
}

