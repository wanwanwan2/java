package Department;

public class ProductDTO {
	
	private int num;
	private String id;
	private String brand;
	private String name;
	private int price;
	private int energy;
	private char line;
	
	public ProductDTO() {}
	
	public ProductDTO(int num, String id, String brand, String name, int price, int energy, char line) {
		super();
		this.num = num;
		this.id = id;
		this.name = name;
		this.brand = brand;
		this.price = price;
		this.energy = energy;
		this.line = line;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) {
		this.energy = energy;
	}

	public char getLine() {
		return line;
	}

	public void setLine(char line) {
		this.line = line;
	}
	
	public String getInformation() {
		return "ProductDTO [num=" + num +
				",id=" + id +
				", brand=" + brand +
				", name=" + name +
				", price=" + price +
				", energy=" + energy +
				", line=" + line +
				"]";
	}
}