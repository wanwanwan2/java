package Department;

public class ProductInsertManager {

	public void insert(ProductDTO[] products) {
		
		System.out.println("물건을 주문합니다.");
		
		for(int i = 0; i < products.length; i++) {
			System.out.println(products[i].getName() + "제품을 주문 등록에 성공했습니다.");
		}
		System.out.println("총 " + products.length + "개의 제품을 주문했습니다.");
	}
}
