package Department;

public class ProductManager {

	public void signUpProducts() {
		
		ProductDTO[] products = new ProductDTO[5];
		
		products[0] = new ProductDTO(1, "시리즈 1" , "헤이쥐", "냉장고", 1000000, 1, '유');
		products[1] = new ProductDTO(2, "시리즈 2" , "삼송", "TV", 2000000, 1, '유');
		products[2] = new ProductDTO(3, "시리즈 3" , "삼송", "청소기", 100000, 1, '무');
		products[3] = new ProductDTO(4, "시리즈 4" , "헤이쥐", "에어컨", 3000000, 1, '유');
		products[4] = new ProductDTO(5, "시리즈 5" , "DILL", "컴퓨터", 1000000, 1, '유');
		
		ProductInsertManager productInsertManager = new ProductInsertManager();
		productInsertManager.insert(products);
	}
	
	public void printAllProducts() {
		
		ProductDTO[] selectedProducts = new ProductSelectManager().selectAllPrducts();
		
		System.out.println("------- 주문된 제품 목록 --------");
		for(ProductDTO product : selectedProducts) {
			System.out.println(product.getInformation());
		}
		System.out.println("------------------------------");
		System.out.println("총 " + selectedProducts.length + "제품이 주문되어있습니다.");
	}
}
