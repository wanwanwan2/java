package Department;

public class ProductSelectManager {

	public ProductDTO[] selectAllPrducts() {
		
		return new ProductDTO[] {
		
		new ProductDTO(1, "시리즈 1" , "헤이쥐", "냉장고", 1000000, 1, '유'),
		new ProductDTO(2, "시리즈 2" , "삼송", "TV", 2000000, 1, '유'),
		new ProductDTO(3, "시리즈 3" , "삼송", "청소기", 100000, 1, '무'),
		new ProductDTO(4, "시리즈 4" , "헤이쥐", "에어컨", 3000000, 1, '유'),
		new ProductDTO(5, "시리즈 5" , "DILL", "컴퓨터", 1000000, 1, '유'),		
		};
	}
}
