package answer;

import java.util.Scanner;

public class Clock {
	
	public static void main(String[] args) {

	/*0시부터 입력받은 시의 일분 전까지 매분 알람이 울릴수 있도록 해보아라*/	
	
		
		Scanner sc = new Scanner(System.in);
		System.out.println("시: ");
		int hour = sc.nextInt();
		System.out.println("분: ");
		int min = sc.nextInt();
		
		
		for(int i = 0; i < 12; i++) {
			if(1 <=min && min < 60)
			 {
				System.out.println("알람");
			 }
		}
	}
}
