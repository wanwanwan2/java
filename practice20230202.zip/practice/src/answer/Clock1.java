package answer;

import java.util.Scanner;

public class Clock1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("시를 입력하시오");
		int a = sc.nextInt();
		//			System.out.println("분을 입력하시오");
		//			int b = sc.nextInt();


		for(int i=0;i < a;i++) {

			for(int j=0; j < 60;j++) {
				System.out.println(i+"시"+j+"분 입니다.");	

			}
		}
	}
}
