package answer;

public class Mathrandom {

	public static void main(String[] args) {
		
		/*5 ~ 15 사이 두 개의 난수를 발생시켜 두 난수 사이의 값의 총합을 구하라.
		동일한 값일 경우 "다시 실행하세요."라는 문구를 출력하고 종료하라.
		======= 출력 예시 =======
		난수1 : 11
		난수2 : 6
		총합 : 51*/
		
				
		int a = (int)(Math.random() * 6) + 5;
//		int
		
	}

}
