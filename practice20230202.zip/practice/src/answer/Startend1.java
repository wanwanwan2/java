package answer;

import java.util.Scanner;

public class Startend1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
 		
 		int random1 = sc.nextInt(); 
 		int random2 = sc.nextInt(); 

 		int start = random2 < random1 ? random2 : random1; 
		int end  = random1 < random2 ? random2 : random1;
		
         for(int i = start ; i <= end ; i++) {
			
        	if(i % 2 ==0) {
			System.out.println(i);
        	}			
		}

	}

}
