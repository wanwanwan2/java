package answer;

import java.util.Scanner;

public class startend {

	public static void main(String[] args) {
		
		/*star end 두 값을 입력받아 start ~ end까지 짝수만 출력해보자.
		 * */
		
		Scanner sc = new Scanner(System.in);
		System.out.println("start : " );
		int a = sc.nextInt();
		
		System.out.println("end : " );
		int b = sc.nextInt();
		
	for (int i = a; i <= b; i++) {
		if(i % 2 == 0) {
			System.out.println(i);
			}
	
		}
	}
}