package calculator;

import javax.swing.JFrame;

public class C_Calculator {

	public static void main(String[] args) {
		
		JFrame mf = new JFrame();
		

	}

}
