package flow;

public class Application1 {
	
	public static void main(String[] args) {
		
			A_if a = new A_if();
			a.testSimpleIfStatement();
			a.testNestedIfStatement();
			
	}
}
