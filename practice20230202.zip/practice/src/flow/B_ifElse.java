package flow;

public class B_ifElse {
	
	public void testsimlpIfElseStatement() {
		
		/* [if-else문 표현식] 
		 * if(조건식)
		 * 		조건이 true일 때 실행할 명령문;
		 * } else {
		 * 		조건이 false일 때 실행할 명령문;
		 * }
		 * */
		
		/* 정수 한 개를 입력 받아 그 수가 홀수이면 "입력하신 숫자는 홀 수 */
		
		
	}
} 
