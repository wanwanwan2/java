package game;

public class Team1 {

	public static void main(String[] args) {
		
	
		int cash = 10000;
		int apple = 1000;
		int banana = 2000;
		int change1 = cash - apple;
		int change2 = cash - banana;
		
//		Question app = new Question();
//		app.buyA(change1);
//		app.buyB(change2);
		
	}
	
//	public void methodA()
//		System.out.println
	
	}
//}
