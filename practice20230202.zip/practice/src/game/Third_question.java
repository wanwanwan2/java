package game;

public class Third_question {

	public static void main(String[] args) {
		
	Third_question app1 = new Third_question();
	
	/* 1. 전달인자로 값 전달 테스트*/
	app1.testMethod(31);
	
	/* 2. 변수에 저장한 값 전달 테스트 */
	int age = 31;
	app1.testMethod(age);
	
	/* 3. 자동형변환을 이용해서 값 전달 테스트*/
	byte byteAge = 31;
	app1.testMethod(byteAge);
	
	/* 4. 강제형변환을 이용해서 값 전달 테스트 */
	long longAge = 31;
	app1.testMethod((int) longAge);
	
	/* 5. 연산 결과를 이용해서 값 전달을 할 수 있다. */
	app1.testMethod(age*2);
	
	}
	
	public void testMethod(int age) {
		System.out.println("당신의 나이는 " + age + "세 입니다.");
	}
	
}
