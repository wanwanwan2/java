package literal;


public class Application2 {

	public static void main(String[] args) {
	
		/* 값을 직접 연산하여 출력 할 수 있다.
		 * 이 때의 값의 형태에 따라 사용할 수 있는 연산자의 종류와 연산의 결과가 달라진다.
		 * */
		
		/* 1. 숫자와 숫자의 연산 */
		/* 1-1. 정수와 정수의 연산 */
		System.out.println("===== 정수와 정수의 연산 =====");
		System.out.println(123 + 456);
		System.out.println(123 - 23);
		System.out.println(123 * 10);
		System.out.println(123 / 10);	//정수와 정수의 연산 결과는 정수가 나온다.
		System.out.println(123 % 10);	//모드(mod)연산 -> 두 수를 나눈 나머지 반환 
		
		/* 1-2. 실수와 실수의 연산 */
		System.out.println("===== 실수와 실수의 연산=====");
		System.out.println(1.23 + 1.23);
		System.out.println(1.23 - 0.23); //실수와 실수의 연산 결과는 실수가 나온다.
		System.out.println(1.23 * 10.0);
		System.out.println(1.23 / 10.0);
		System.out.println(1.23 % 10.0);
		
		/* 1-3. 정수와 실수의 연산*/
		/* 정수와 실수의 연산 결과는 항상 실수가 나온다.*/
		System.out.println("===== 정수와 실수의 연산 =====");
		System.out.println(123 + 0.5);
		System.out.println(123 - 0.5);
		System.out.println(123 * 0.5);
		System.out.println(123 / 0.5);
		System.out.println(123 % 0.5);
		
		/* 2. 문자의 연산 */
		/* 2-1. 문자와 문자의 연산 */
		/* 문자는 숫자로 인식된다. 따라서 숫자에 사용 가능한 연산이 전부 사용 가능하다. */
		System.out.println("===== 문자와 문자의 연산 =====");
		System.out.println('a' + 'b');
		System.out.println('a' - 'b');
		System.out.println('a' * 'b');
		System.out.println('a' / 'b');
		System.out.println('a' % 'b');
		
		
		
	}

}
