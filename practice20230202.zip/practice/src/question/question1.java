package question;

import java.util.Scanner;

public class question1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("첫 번째 양수를 입력하시오. :");
		int dan = sc.nextInt();
		
		if(dan >=1 && dan <=9)
		{
			for (int num = 1; num <= 9; num++)
			{
				System.out.println(dan + " * " + num + " = " + (dan * num));
			}
		}
		else
		{
			System.out.println("반드시 1 ~ 9 사이의 양수를 입력해야 합니다.");
		}

	}

}
