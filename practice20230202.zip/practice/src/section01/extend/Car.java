package section01.extend;

public class Car {

}
