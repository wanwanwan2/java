package singleton;

public class EagerSingleton {

}
