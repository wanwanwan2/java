package singleton;

public class LazySingleton {

}
