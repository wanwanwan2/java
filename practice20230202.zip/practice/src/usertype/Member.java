package usertype;

public class Member {
	
	String id;
	String pwd;
	String name;
	int age;
	char gender;
	String[] hobby;
}
