package variable;

public class Application1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* 변수의 사용 목적
		 * 1. 값에 의미를 부여하기 위한 목적
		 * 2. 한번 값을 저장하하고 재사용을 하기 위한 목적
		 * 3. 시간에 따라 변하는 값을 저장하고 사용하기 위한 목적
		 * */
		
		
	}

}
